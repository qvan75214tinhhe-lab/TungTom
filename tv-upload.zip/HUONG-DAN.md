# Hướng dẫn làm web Upload & Xem trực tiếp (chạy được trên TV yếu)

## 1. Web này làm được gì
- Upload video, nhạc, ảnh (tối đa 1GB), có thanh phần trăm.
- Upload xong tự phát ngay, bấm vào file cũ trong danh sách để xem lại.
- Nhẹ: không thư viện, không hiệu ứng. Nút to, điều khiển được bằng remote TV.
- Tua video không cần tải hết file (server hỗ trợ Range).

## 2. Cấu trúc thư mục
```
tv-upload/
├── index.html     giao diện (trang web)
├── server.js      máy chủ nhận file và phát video
├── package.json
└── uploads/       tự tạo khi chạy, chứa file đã upload
```

## 3. Chạy thử trên máy tính (từng bước)
1. Tải Node.js bản LTS tại https://nodejs.org và cài đặt.
2. Giải nén file zip, mở thư mục `tv-upload`.
3. Mở Terminal (Windows: gõ `cmd` vào thanh địa chỉ của thư mục rồi Enter).
4. Gõ: `node server.js`
5. Màn hình hiện địa chỉ, ví dụ `http://192.168.1.10:3000`.
6. Mở địa chỉ đó trên máy tính để thử trước.

## 4. Xem trên TV / điện thoại
- TV và máy tính phải **cùng Wi-Fi**.
- Mở trình duyệt của TV, gõ đúng địa chỉ ở bước 3.5.
- Dùng remote di chuyển giữa các nút, nút đang chọn có viền vàng.
- Không vào được? Tắt tạm tường lửa (Windows Firewall) hoặc cho phép Node.js qua mạng riêng.

## 5. Mẹo để TV yếu xem mượt
- Dùng file **.mp4, mã hóa H.264, âm thanh AAC**. Đây là định dạng gần như TV nào cũng phát được.
- TV yếu thường **không phát được** .mkv, H.265/HEVC, 4K. Nên hạ về 720p hoặc 1080p.
- Chuyển định dạng bằng HandBrake (miễn phí) hoặc ffmpeg:
  `ffmpeg -i input.mkv -c:v libx264 -preset fast -crf 23 -vf scale=-2:720 -c:a aac -movflags +faststart output.mp4`
  (`+faststart` giúp video bắt đầu phát sớm, không phải chờ tải hết.)
- Nếu trang báo "Thiết bị không phát được định dạng này", hãy chuyển file như trên.

## 6. Đặt mật khẩu (nên làm nếu mở ra internet)
- Windows (cmd): `set PASSWORD=matkhau123 && node server.js`
- Mac/Linux: `PASSWORD=matkhau123 node server.js`
- Trình duyệt sẽ hỏi đăng nhập: tên để trống, mật khẩu nhập như trên.

## 7. Đưa lên mạng để dùng từ xa (VPS)
GitHub Pages **không chạy được** `server.js`, nên không lưu được file. Bạn cần VPS hoặc host Node.js.
1. Thuê VPS Ubuntu, cài Node.js.
2. Chép thư mục `tv-upload` lên VPS (WinSCP hoặc `scp`).
3. Cài pm2 để chạy nền: `npm i -g pm2`
4. Chạy: `PASSWORD=matkhau123 pm2 start server.js --name tv-upload`
5. Giữ chạy sau khi khởi động lại: `pm2 save && pm2 startup`
6. Mở cổng 3000 trên firewall của VPS, rồi vào `http://IP-VPS:3000`.
7. Có tên miền và HTTPS thì dùng Nginx hoặc Caddy làm proxy tới cổng 3000. Nhớ cho phép file lớn: trong Nginx đặt `client_max_body_size 1g;`.

## 8. Đưa mã nguồn lên GitHub
1. Tạo repo mới trên github.com.
2. Upload `index.html`, `server.js`, `package.json`. **Không** upload thư mục `uploads/` (file của người dùng).
3. Tạo file `.gitignore` chứa dòng: `uploads/`
4. Nếu bật GitHub Pages, trang chỉ chạy ở **chế độ xem tạm trên máy**: chọn file là phát luôn nhưng không lưu.

## 9. Giải thích code ngắn gọn
**index.html**
- `play(url, name)`: tự chọn thẻ `<video>`, `<audio>` hoặc `<img>` theo đuôi file.
- `loadList()`: hỏi server `/files` để hiện danh sách. Nếu không có server thì chuyển sang chế độ tạm.
- Nút Upload gửi file bằng XHR `PUT /upload` và cập nhật thanh phần trăm.

**server.js**
- `PUT /upload`: ghi file thẳng xuống ổ đĩa theo luồng, không nạp cả file vào RAM.
- `GET /uploads/<tên>`: trả file, có xử lý header `Range` để tua nhanh.
- `GET /files`: trả danh sách file dạng JSON.
- Chỉ nhận đuôi trong danh sách `TYPES` (video, nhạc, ảnh), chặn các file như .exe, .php.

## 10. Thêm tính năng sau này
- Nút xóa file: thêm route `DELETE /uploads/<tên>` rồi dùng `fs.unlink`.
- Giới hạn dung lượng khác: đổi hằng số `MAX` trong `server.js` và `1073741824` trong `index.html`.
- Đổi cổng: `PORT=8080 node server.js`.

## 11. Lỗi thường gặp
| Lỗi | Cách xử lý |
|---|---|
| TV không vào được địa chỉ | Kiểm tra cùng Wi-Fi, tắt firewall, gõ đúng IP và cổng |
| Video đen, có tiếng hoặc ngược lại | Chuyển sang mp4 H.264 + AAC |
| Upload dừng giữa chừng | Mạng yếu, thử lại; nếu dùng Nginx hãy tăng `client_max_body_size` |
| `node` không nhận lệnh | Cài lại Node.js, mở lại Terminal |
| Cổng 3000 đã bị dùng | Chạy với cổng khác: `PORT=3001 node server.js` |
