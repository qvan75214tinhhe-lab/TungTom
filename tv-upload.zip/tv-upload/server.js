// Chạy: node server.js  → mở http://IP-máy:3000
// Đặt mật khẩu (tuỳ chọn):  PASSWORD=matkhau node server.js
const http = require("http"), fs = require("fs"), path = require("path"), os = require("os");
const DIR = path.join(__dirname, "uploads");
const MAX = 1024 * 1024 * 1024; // 1GB
const PORT = process.env.PORT || 3000;
const PASSWORD = process.env.PASSWORD || "";
fs.mkdirSync(DIR, { recursive: true });

const TYPES = {
  ".mp4": "video/mp4", ".webm": "video/webm", ".mkv": "video/x-matroska",
  ".mov": "video/quicktime", ".3gp": "video/3gpp",
  ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".ogg": "audio/ogg",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
  ".gif": "image/gif", ".webp": "image/webp"
};

function send(res, code, body, type) {
  res.writeHead(code, { "Content-Type": type || "text/plain; charset=utf-8" });
  res.end(body);
}

function authorized(req) {
  if (!PASSWORD) return true;
  const h = req.headers.authorization || "";
  if (!h.startsWith("Basic ")) return false;
  const pass = Buffer.from(h.slice(6), "base64").toString().split(":").slice(1).join(":");
  return pass === PASSWORD;
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return ""; }
}

function handle(req, res) {
  if (!authorized(req)) {
    res.writeHead(401, { "WWW-Authenticate": 'Basic realm="Upload"' });
    return res.end("Cần mật khẩu");
  }
  const url = req.url.split("?")[0];

  if (req.method === "GET" && (url === "/" || url === "/index.html"))
    return send(res, 200, fs.readFileSync(path.join(__dirname, "index.html")), "text/html; charset=utf-8");

  if (req.method === "GET" && url === "/files") {
    const list = [];
    for (const n of fs.readdirSync(DIR)) {
      if (!TYPES[path.extname(n).toLowerCase()]) continue;
      try {
        const st = fs.statSync(path.join(DIR, n));
        list.push({ name: n, size: st.size, t: st.mtimeMs });
      } catch (e) { /* file vừa bị xoá */ }
    }
    list.sort((a, b) => b.t - a.t);
    return send(res, 200, JSON.stringify(list), "application/json");
  }

  if (req.method === "PUT" && url === "/upload") {
    let name = path.basename(safeDecode(req.headers["x-filename"] || ""));
    const ext = path.extname(name).toLowerCase();
    if (!TYPES[ext]) return send(res, 400, "Định dạng không được hỗ trợ");
    if (+req.headers["content-length"] > MAX) return send(res, 413, "File quá lớn (tối đa 1GB)");
    name = Date.now() + "-" + name.replace(/[^\w.\- ]/g, "_");
    const full = path.join(DIR, name);
    const out = fs.createWriteStream(full);
    let done = false;
    req.pipe(out);
    out.on("finish", () => { done = true; send(res, 200, name); });
    out.on("error", () => send(res, 500, "Lỗi ghi file"));
    // Người dùng huỷ giữa chừng → xoá file dở
    res.on("close", () => { if (!done) { out.destroy(); fs.unlink(full, () => {}); } });
    return;
  }

  if (req.method === "GET" && url.startsWith("/uploads/")) {
    const file = path.join(DIR, path.basename(safeDecode(url.slice(9))));
    const type = TYPES[path.extname(file).toLowerCase()];
    if (!type || !fs.existsSync(file)) return send(res, 404, "Không tìm thấy");
    const size = fs.statSync(file).size;
    const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || "");
    // Hỗ trợ Range: TV/trình duyệt tua và tải từng phần, không cần tải hết file
    if (m) {
      let s = m[1] ? +m[1] : 0, e = m[2] ? +m[2] : size - 1;
      if (!m[1] && m[2]) { s = Math.max(0, size - +m[2]); e = size - 1; }
      if (e >= size) e = size - 1;
      if (s > e || s >= size) { res.writeHead(416, { "Content-Range": "bytes */" + size }); return res.end(); }
      res.writeHead(206, {
        "Content-Type": type, "Accept-Ranges": "bytes",
        "Content-Range": `bytes ${s}-${e}/${size}`, "Content-Length": e - s + 1
      });
      return fs.createReadStream(file, { start: s, end: e }).on("error", () => res.destroy()).pipe(res);
    }
    res.writeHead(200, { "Content-Type": type, "Accept-Ranges": "bytes", "Content-Length": size });
    return fs.createReadStream(file).on("error", () => res.destroy()).pipe(res);
  }

  send(res, 404, "Không tìm thấy");
}

http.createServer((req, res) => {
  try { handle(req, res); }
  catch (e) { console.error(e); if (!res.headersSent) send(res, 500, "Lỗi server"); else res.destroy(); }
}).listen(PORT, () => {
  console.log("Server đang chạy. Mở một trong các địa chỉ sau trên điện thoại/TV:");
  const nets = os.networkInterfaces();
  for (const k in nets) for (const n of nets[k])
    if (n.family === "IPv4" && !n.internal) console.log("  http://" + n.address + ":" + PORT);
  if (PASSWORD) console.log("Đã bật mật khẩu (tên đăng nhập: để trống hoặc gõ gì cũng được).");
});
